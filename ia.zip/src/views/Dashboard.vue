<template>
  <AppLayout>
    <div class="min-h-screen">
      <div class="p-4 lg:p-6 max-w-7xl mx-auto">
        <div class="mb-8">
          <div class="flex flex-col lg:flex-row justify-between items-start lg:items-center gap-4">
            <div>
              <h1 class="text-3xl font-bold text-white mb-2">Copy Trader IA</h1>
              <p class="text-gray-400">Bem-vindo(a), {{ userDisplayName }}</p>
            </div>

            <div class="flex items-center gap-4">
              <div class="glass-card px-6 py-3 rounded-xl">
                <div class="flex items-center gap-3">
                  <div>
                    <p class="text-xs text-gray-400">Saldo</p>
                    <p class="text-xl font-bold text-blue-400">{{ formatCurrency(balance) }}</p>
                  </div>
                  <div class="w-px h-10 bg-gray-700"></div>
                  <button @click="switchAccount"
                    class="px-3 py-1.5 rounded-lg bg-blue-500/20 text-blue-400 hover:bg-blue-500/30 transition-all text-sm">
                    {{ accountType === 'demo' ? 'DEMO' : 'REAL' }}
                  </button>
                </div>
              </div>
            </div>
          </div>
        </div>

        <div class="grid grid-cols-1 lg:grid-cols-3 gap-6 mb-8">
          <div class="lg:col-span-1 space-y-6">
            <div class="glass-card p-6 rounded-2xl">
              <h3 class="text-lg font-bold text-white mb-4 flex items-center gap-2">
                <i class="fas fa-coins text-blue-400"></i>
                Selecionar Ativo
              </h3>

              <div class="space-y-3">
                <div class="relative">
                  <select v-model="selectedAsset"
                    class="w-full bg-slate-900/50 border border-slate-700 text-white px-4 py-3 rounded-xl focus:outline-none focus:border-blue-500 transition-all">
                  
                    <option v-for="asset in availableAssets" :key="asset.name" :value="asset.name">
                      {{ asset.name }}
                    </option>
                  </select>
                </div>

                <div>
                  <label class="text-sm text-gray-400 mb-2 block">Tempo de Expiração</label>
                  <div class="grid grid-cols-3 gap-2">
                    <button v-for="time in [1, 5]" :key="time" @click="selectedTime = time"
                      :class="['py-2 rounded-lg font-medium transition-all', selectedTime === time ? 'bg-blue-500 text-white' : 'bg-slate-900/50 text-gray-400 border border-slate-700 hover:border-blue-500']">
                      {{ time }}M
                    </button>
                  </div>
                </div>

                </div>
            </div>

            <div class="glass-card p-6 rounded-2xl">
              <h3 class="text-lg font-bold text-white mb-4 flex items-center gap-2">
                <i class="fas fa-robot text-blue-400"></i>
                Gerador de Sinais IA
              </h3>
              <div class="space-y-4">
                <button @click="handleGenerateSignal"
                        :disabled="isGeneratingSignal"
                        class="w-full py-3 rounded-xl font-bold transition-all flex items-center justify-center gap-2 bg-gradient-to-r from-blue-500 to-blue-600 text-white hover:from-blue-600 hover:to-blue-700 disabled:opacity-50 disabled:cursor-not-allowed">
                  <i :class="isGeneratingSignal ? 'fas fa-spinner fa-spin' : 'fas fa-wand-magic-sparkles'"></i>
                  {{ isGeneratingSignal ? 'Gerando...' : 'Gerar Sinal' }}
                </button>
              </div>
            </div>
          </div>

          <div class="lg:col-span-2">
            <div class="glass-card p-6 rounded-2xl h-full min-h-[500px]">
              <div class="flex justify-between items-center mb-4">
                 <h3 class="text-lg font-bold text-white flex items-center gap-2">
                  <i class="fas fa-chart-line text-blue-400"></i>
                  Gráfico de Atividade
                </h3>
              </div>

              <div class="bg-slate-900/50 rounded-xl">
                 <apexchart
                   v-if="chartSeries[0].data.length > 0"
                   type="candlestick"
                   height="400"
                   :options="chartOptions"
                   :series="chartSeries"
                 ></apexchart>
                 <div v-else class="h-[400px] flex flex-col items-center justify-center text-gray-500">
                    <i class="fas fa-spinner fa-spin text-4xl text-blue-400/50"></i>
                    <p class="mt-4">Carregando dados do gráfico...</p>
                 </div>
              </div>
            </div>
          </div>
        </div>

        <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
          <div class="glass-card p-6 rounded-2xl">
            <div class="flex items-center justify-between mb-4">
              <div class="w-12 h-12 bg-green-500/20 rounded-xl flex items-center justify-center">
                <i class="fas fa-trophy text-green-400"></i>
              </div>
              <span class="text-2xl font-bold text-green-400">{{ transactionStats.winPercent }}%</span>
            </div>
            <h4 class="text-gray-400 text-sm">Taxa de Acerto</h4>
            <div class="mt-3 h-2 bg-slate-800 rounded-full overflow-hidden">
              <div class="h-full bg-gradient-to-r from-green-500 to-green-400"
                :style="{ width: `${transactionStats.winPercent}%` }"></div>
            </div>
          </div>

          <div class="glass-card p-6 rounded-2xl">
            <div class="flex items-center justify-between mb-4">
              <div class="w-12 h-12 bg-blue-500/20 rounded-xl flex items-center justify-center">
                <i class="fas fa-exchange-alt text-blue-400"></i>
              </div>
              <span class="text-2xl font-bold text-white">{{ transactionStats.total }}</span>
            </div>
            <h4 class="text-gray-400 text-sm">Total de Operações</h4>
            <div class="mt-3 flex gap-4 text-xs">
              <span class="text-green-400">{{ transactionStats.wins }} wins</span>
              <span class="text-red-400">{{ transactionStats.losses }} losses</span>
            </div>
          </div>

          <div class="glass-card p-6 rounded-2xl">
            <div class="flex items-center justify-between mb-4">
              <div class="w-12 h-12 bg-purple-500/20 rounded-xl flex items-center justify-center">
                <i class="fas fa-chart-line text-purple-400"></i>
              </div>
              <span class="text-2xl font-bold text-purple-400">{{ formatCurrency(transactionStats.totalProfit) }}</span>
            </div>
            <h4 class="text-gray-400 text-sm">Lucro Total</h4>
            <div class="mt-3">
              <span class="text-xs text-gray-500">ROI: {{ roiStats.totalROI }}%</span>
            </div>
          </div>

          <div class="glass-card p-6 rounded-2xl">
            <div class="flex items-center justify-between mb-4">
              <div class="w-12 h-12 bg-cyan-500/20 rounded-xl flex items-center justify-center">
                <i class="fas fa-users text-cyan-400"></i>
              </div>
              <span class="text-2xl font-bold text-white">1,234</span>
            </div>
            <h4 class="text-gray-400 text-sm">Traders Ativos</h4>
            <div class="mt-3">
              <span class="text-xs text-green-400">+12% hoje</span>
            </div>
          </div>
        </div>

        <div class="glass-card p-6 rounded-2xl">
          <div class="flex justify-between items-center mb-6">
            <h3 class="text-lg font-bold text-white flex items-center gap-2">
              <i class="fas fa-history text-blue-400"></i>
              Operações Recentes
            </h3>
            <button @click="showTransactionHistory" class="text-blue-400 hover:text-blue-300 transition-all text-sm">
              Ver todas <i class="fas fa-arrow-right ml-1"></i>
            </button>
          </div>

          <div class="overflow-x-auto">
            <table class="w-full">
              <thead>
                <tr class="text-gray-400 text-sm">
                  <th class="text-left pb-4">Ativo</th>
                  <th class="text-left pb-4">Direção</th>
                  <th class="text-left pb-4">Tempo</th>
                  <th class="text-right pb-4">Resultado</th>
                </tr>
              </thead>
              <tbody>
                <tr
                  v-for="(item, idx) in [...history].sort((a, b) => new Date(b.payload?.closeTime || b.createdAt) - new Date(a.payload?.closeTime || a.createdAt)).slice(0, 5)"
                  :key="idx" class="border-t border-slate-800">
                  <td class="py-3">
                    <div class="flex items-center gap-2">
                      <img :src="getCurrencyFlag(item.payload?.active?.name || 'EURUSD', 0)"
                        class="w-5 h-5 rounded-full">
                      <img :src="getCurrencyFlag(item.payload?.active?.name || 'EURUSD', 1)"
                        class="w-5 h-5 rounded-full -ml-2">
                      <span class="text-white">{{ item.payload?.active?.name || 'N/A' }}</span>
                    </div>
                  </td>
                  <td class="py-3">
                    <span :class="item.payload?.pnl >= 0 ? 'text-green-400' : 'text-red-400'"
                      class="flex items-center gap-1">
                      <i :class="item.payload?.pnl >= 0 ? 'fas fa-arrow-up' : 'fas fa-arrow-down'"></i>
                      {{ item.payload?.pnl >= 0 ? 'CALL' : 'PUT' }}
                    </span>
                  </td>
                  <td class="py-3 text-gray-400">{{ formatDateTime(item.payload?.closeTime || item.createdAt) }}</td>
                  <td class="py-3 text-right">
                    <span :class="item.payload?.pnl >= 0 ? 'text-green-400' : 'text-red-400'" class="font-medium">
                      {{ item.payload?.pnl >= 0 ? '+' : '' }}{{ formatCurrency(item.payload?.pnl || 0) }}
                    </span>
                  </td>
                </tr>
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  </AppLayout>
</template>

<script setup>
import { ref, onMounted, computed, watch, nextTick, onUnmounted } from 'vue'
import { useRouter } from 'vue-router'
import Swal from 'sweetalert2'
import AppLayout from '@/components/AppLayout.vue'
import Apexchart from 'vue3-apexcharts'
import axios from 'axios'
import { io } from 'socket.io-client'
const router = useRouter()

// State variables
const userDisplayName = ref('Usuário(a)')
const balance = ref(5000)
const accountType = ref('demo')
const isGeneratingSignal = ref(false)
const selectedBroker = ref('homebroker')
const history = ref([])
const GALES = ref(2)
const initialBalance = ref(null)

// Trading variables
const selectedAsset = ref('EURUSD')
const selectedTime = ref(1)
const defaultUserSettings = { entryValue: 10, stopWin: 100, stopLoss: 100 }
const userSettings = ref({ ...defaultUserSettings })
const COLLECTION_NAME = 'autopilot'

// --- CHART STATE AND OPTIONS ---
let chartUpdateInterval = null;
const chartSeries = ref([{ data: [] }]);

const chartOptions = computed(() => ({
  chart: {
    type: 'candlestick',
    height: 400,
    background: 'transparent',
    toolbar: { show: false },
    zoom: { enabled: false }
  },
  title: {
    text: `Gráfico de ${selectedAsset.value}`,
    align: 'left',
    style: {
      fontSize: '16px',
      color: '#E2E8F0',
    }
  },
  xaxis: {
    type: 'datetime',
    labels: { style: { colors: '#94A3B8' } },
    axisBorder: { show: false },
    axisTicks: { color: '#334155' }
  },
  yaxis: {
    tooltip: { enabled: true },
    labels: {
      style: { colors: '#94A3B8' },
      formatter: function (val) {
        if (typeof val === 'number') {
          return val.toFixed(5);
        }
        return '';
      }
    },
    opposite: true
  },
  grid: {
    borderColor: 'rgba(59, 130, 246, 0.1)',
    xaxis: { lines: { show: true } },
    yaxis: { lines: { show: true } }
  },
  tooltip: {
    theme: 'dark',
    style: { fontSize: '12px', fontFamily: 'monospace' }
  },
  plotOptions: {
    candlestick: {
      colors: {
        upward: '#22c55e',
        downward: '#ef4444'
      },
      wick: { useFillColor: true }
    }
  },
  series: [{
    data: chartSeries.value[0].data,
  }]
}));

const updateChart = async () => {
  try {
    const candleData = await getCandles(selectedAsset.value, selectedTime.value * 60);
    const candles = candleData.results;

    if (Array.isArray(candles) && candles.length > 0) {
      const seriesData = candles.map(candle => ({
        x: new Date(candle.time).getTime(), 
        y: [candle.open, candle.high, candle.low, candle.close]
      }));
      chartSeries.value = [{ data: seriesData }];
    } else {
       chartSeries.value = [{ data: [] }];
    }
  } catch (error) {
    console.error("Erro ao atualizar os candles do gráfico:", error);
  }
};
// --- END OF CHART LOGIC ---

// Função padrão para mostrar notificações (toasts)
function showToast(title, icon = 'info', timer = 4000) {
  Swal.fire({
    title,
    icon,
    toast: true,
    position: 'top-end',
    showConfirmButton: false,
    timer: timer,
    timerProgressBar: true,
    background: 'rgba(26, 31, 53, 0.95)',
    color: '#fff',
    customClass: { popup: `custom-toast` }
  })
}

const handleGenerateSignal = async () => {
  isGeneratingSignal.value = true;
  showToast('Buscando candles e gerando sinal...', 'info');

  try {
    const pair = selectedAsset.value;
    const period = selectedTime.value;

    const candlesResponse = await getCandles(pair, period);
    if (!candlesResponse || !candlesResponse.results || !Array.isArray(candlesResponse.results) || candlesResponse.results.length === 0) {
      throw new Error('Não foram retornados candles para gerar o sinal.');
    }

    const signalResponse = await generateSignal(pair, period, candlesResponse.results);
    if (!signalResponse || !signalResponse.data || !signalResponse.data.trade_action || !signalResponse.data.entry_time) {
      throw new Error('Sinal não encontrado, tente novamente.');
    }
    
    Swal.close();
    
    const data = {
      pair,
      timeframe: period * 60,
      ...signalResponse.data
    };
    showSignalConfirmationPopup(data);

  } catch (error) {
    console.error("Erro ao gerar sinal:", error);
    showToast(error.message, 'error', 6000);
  } finally {
    isGeneratingSignal.value = false;
  }
};

const showSignalConfirmationPopup = (signal) => {
  const { pair, timeframe, entry_time, trade_action } = signal;

  const directionText = trade_action === 'BUY'
    ? `<span style="color: #4ade80; font-weight: bold;">COMPRA</span>`
    : `<span style="color: #f87171; font-weight: bold;">VENDA</span>`;

  Swal.fire({
    title: `<span style='color:#fff;font-weight:bold;'>Sinal Encontrado!</span>`,
    html: `
      <div style="color: #cbd5e1; text-align: left; display: grid; grid-template-columns: 1fr 2fr; gap: 8px 16px; align-items: center;">
        <strong style="color: #94a3b8;">Ativo:</strong>         <span>${pair}</span>
        <strong style="color: #94a3b8;">Expiração:</strong>    <span>${timeframe / 60} Minuto(s)</span>
        <strong style="color: #94a3b8;">Entrada:</strong>      <span>${formatDateTime(entry_time)}</span>
        <strong style="color: #94a3b8;">Ação:</strong>         <span>${directionText}</span>
      </div>
    `,
    icon: 'info',
    background: 'linear-gradient(135deg, rgba(26,31,53,0.98) 80%, rgba(99,102,241,0.13) 100%)',
    showCancelButton: true,
    confirmButtonText: 'Confirmar Operação',
    cancelButtonText: 'Cancelar',
    confirmButtonColor: '#3B82F6',
    cancelButtonColor: '#be123c',
  }).then(async (result) => {
    if (result.isConfirmed) {
      /* const entryDate = new Date(entry_time);
      entryDate.setHours(entryDate.getHours() - 3);
      entryDate.setSeconds(0, 0); // ignora os segundos

      const now = new Date();
      const msToWait = entryDate.getTime() - now.getTime();

      if (msToWait > 0) {
        // Notificação tipo toast fixa no canto superior direito até o horário de entrada, sem piscar
        let interval;
        let toastInstance = null;
        await new Promise(resolve => {
          function updateToast(diff) {
            const sec = Math.floor((diff / 1000) % 60);
            const min = Math.floor((diff / 1000 / 60) % 60);
            const hour = Math.floor((diff / 1000 / 60 / 60));
            const countdown = `Restante: ${hour > 0 ? hour + 'h ' : ''}${min > 0 ? min + 'm ' : ''}${sec}s`;
            if (!toastInstance) {
              toastInstance = Swal.fire({
                toast: true,
                position: 'top-end',
                showConfirmButton: false,
                timer: undefined,
                timerProgressBar: false,
                background: 'rgba(26, 31, 53, 0.95)',
                color: '#fff',
                icon: 'info',
                title: 'Aguardando horário de entrada',
                html: `<div style="color:#cbd5e1;">${formatDateTime(entryDate)}<br><span id="countdown-wait">${countdown}</span></div>`,
                didOpen: () => {
                  // nada
                }
              });
            } else {
              const el = Swal.getHtmlContainer()?.querySelector('#countdown-wait');
              if (el) el.innerHTML = countdown;
            }
          }

          updateToast(msToWait);

          interval = setInterval(() => {
            const now = new Date();
            let diff = entryDate.getTime() - now.getTime();
            if (diff < 0) diff = 0;
            updateToast(diff);
            if (diff <= 0) {
              clearInterval(interval);
              Swal.close();
              resolve();
            }
          }, 1000);
        });
      } */
      const tradeData = {
        pair: pair,
        direction: trade_action === 'BUY' ? 'CALL' : 'PUT',
        period: timeframe ,
      };
      await executeTradeFromSignal(tradeData);
    }
  });
};

const executeTradeFromSignal = async (signalData) => {
  const { pair, direction, period } = signalData;

  Swal.fire({
    toast: true,
    position: 'top-end',
    showConfirmButton: false,
    timer: undefined,
    background: 'rgba(26, 31, 53, 0.95)',
    color: '#fff',
    icon: 'info',
    title: 'Operação em Andamento',
    html: `<div id="swal-trade-status">Iniciando para ${pair}...</div>`,
    didOpen: () => Swal.showLoading(),
  });

  const updateToastStatus = (text) => {
    const statusEl = document.getElementById('swal-trade-status');
    if (statusEl) statusEl.innerHTML = text;
  };

  await updateBalance();
  initialBalance.value = balance.value;

  const maxAttempts = GALES.value + 1;
  let operationValue = userSettings.value.entryValue;
  let finalResult = { status: 'error', message: 'Operação não finalizada.' };

  for (let attempt = 1; attempt <= maxAttempts; attempt++) {
    if (initialBalance.value !== null) {
      const stopLoss = initialBalance.value - userSettings.value.stopLoss;
      const stopWin = initialBalance.value + userSettings.value.stopWin;
      if (balance.value <= stopLoss) {
        finalResult = { status: 'error', message: 'Stop Loss atingido!' }; break;
      }
      if (balance.value >= stopWin) {
        finalResult = { status: 'success', message: 'Stop Win atingido!' }; break;
      }
    }
    if (balance.value <= 0 || balance.value < operationValue) {
      finalResult = { status: 'error', message: 'Saldo insuficiente.' }; break;
    }

    try {
      updateToastStatus(attempt === 1 ? `Entrando em ordem: ${formatCurrency(operationValue)}` : `Entrando em Gale #${attempt - 1}: ${formatCurrency(operationValue)}`);
      
      const orderResult = await buyDigital({
        assetName: pair, operationValue, direction,
        account_type: accountType.value, period,
      });

      if (!orderResult || !orderResult.order || !orderResult.order.id) {
        throw new Error(orderResult.message || 'Erro ao executar ordem.');
      }

      updateToastStatus('Aguardando resultado da ordem...');
      const uniqueId = `${Date.now()}-${Math.random().toString(36).substr(2, 9)}`;
      const orderStatus = await checkOrderStatus(orderResult.order.id, uniqueId);

      if (!orderStatus || !orderStatus.status) {
        throw new Error('Erro ao verificar status da ordem.');
      }

      if (orderStatus.pnl >= 0) {
        finalResult = { status: 'success', message: 'Resultado: WIN!' };
        break; 
      } else {
        if (attempt < maxAttempts) {
          operationValue *= 2;
        } else {
          finalResult = { status: 'error', message: 'Resultado: LOSS.' };
        }
      }
    } catch (err) {
      finalResult = { status: 'error', message: err.message };
      break;
    }
  }

  Swal.hideLoading();
  Swal.update({
    icon: finalResult.status,
    title: 'Operação Finalizada!',
    html: `<div id="swal-trade-status">${finalResult.message}</div>`,
    timer: 5000,
    timerProgressBar: true,
    showConfirmButton: false,
  });

  await updateBalance();
  await updateAccountGrowthData();
  initialBalance.value = null;
};

const transactionStats = computed(() => {
  if (!Array.isArray(history.value)) return { wins: 0, losses: 0, total: 0, winPercent: 0, totalProfit: 0 };
  const wins = history.value.filter(tx => tx.payload.pnl > 0).length
  const losses = history.value.filter(tx => tx.payload.pnl <= 0).length
  const total = wins + losses
  const winPercent = total ? Math.round((wins / total) * 100) : 0
  const totalProfit = history.value.reduce((sum, tx) => sum + (tx.payload.pnl || 0), 0)
  return { wins, losses, total, winPercent, totalProfit }
});

const roiStats = computed(() => {
  if (!Array.isArray(history.value)) return { totalROI: 0 };
  const totalProfit = transactionStats.value.totalProfit
  const totalInvest = history.value.reduce((sum, tx) => sum + (tx.payload.invest || 0), 0)
  const totalROI = totalInvest ? Math.round((totalProfit / totalInvest) * 100) : 0
  return { totalROI: totalInvest > 0 ? totalROI : 0 }
});

const formatCurrency = (value) => {
  if (typeof value !== 'number') value = 0
  return new Intl.NumberFormat('pt-BR', { style: 'currency', currency: 'BRL' }).format(value)
};

const switchAccount = async () => {
  accountType.value = accountType.value === 'demo' ? 'real' : 'demo'
  await updateBalance()
  await updateAccountGrowthData()
};

const availableAssets = ref([]);

function formatDateTime(dateStr, lang = 'pt-BR') {
  if (!dateStr) return '';
  const date = new Date(dateStr);
  return date.toLocaleDateString(lang, { day: '2-digit', month: '2-digit', year: 'numeric' }) +
    ' - ' + date.toLocaleTimeString(lang, { hour: '2-digit', minute: '2-digit' });
}

const showTransactionHistory = () => {
    const historyArray = Array.isArray(history.value) ? history.value : [];
    const sortedHistory = [...historyArray].sort((a, b) => new Date(b.payload?.closeTime || b.createdAt) - new Date(a.payload?.closeTime || a.createdAt));
    Swal.fire({
        title: `<span style='color:#fff;font-weight:bold;font-size:1.25rem;'>Histórico de Transações</span>`,
        html: `
      <div style="max-height:350px;overflow:auto;background:rgba(36,41,66,0.7);backdrop-filter:blur(8px);border-radius:18px;padding:8px 0 0 0;">
        <table style="width:100%;border-collapse:separate;border-spacing:0 6px;">
          <thead style='position:sticky;top:0;z-index:2;background:rgba(36,41,66,0.95);'>
            <tr style='color:#7dd3fc;font-size:1rem;'>
              <th style='padding:8px 10px;text-align:left;font-weight:600;'>PAR</th>
              <th style='padding:8px 10px;text-align:left;font-weight:600;'>DATA</th>
              <th style='padding:8px 10px;text-align:right;font-weight:600;'>VALOR</th>
            </tr>
          </thead>
          <tbody>
            ${sortedHistory.map((item, idx) => {
              const pnl = item.payload?.pnl || 0;
              const isWin = pnl >= 0;
              return `
                <tr style='background:${idx % 2 === 0 ? "rgba(59,130,246,0.08)" : "rgba(99,102,241,0.10)"};color:${isWin ? '#60a5fa' : '#f87171'};'>
                  <td style='padding:8px 10px;display:flex;align-items:center;gap:7px;'>
                    <i class="fas ${isWin ? 'fa-arrow-up' : 'fa-arrow-down'}"></i>
                    <span>${item.payload?.active?.name || 'N/A'}</span>
                  </td>
                  <td style='padding:8px 10px;'>${formatDateTime(item.payload?.closeTime || item.createdAt)}</td>
                  <td style='padding:8px 10px;text-align:right;'>${isWin ? '+' : ''}${formatCurrency(pnl)}</td>
                </tr>`
            }).join('')}
          </tbody>
        </table>
      </div>`,
        background: 'linear-gradient(135deg, rgba(26,31,53,0.98) 80%, rgba(99,102,241,0.13) 100%)',
        confirmButtonColor: '#6366F1',
        confirmButtonText: `<span style='font-weight:600;'>OK</span>`,
        width: 620,
        showCloseButton: true,
    });
}

const startSdk = async () => {
    const email = localStorage.getItem('userEmail')
    const password = localStorage.getItem('userPassword')
    if (email && password) {
        try {
            await axios.post('/api/sdk/start', { email, password });
        } catch (error) {
            console.error("Erro ao iniciar SDK:", error);
        }
    }
};

const buyDigital = async (payload) => {
  const email = localStorage.getItem('userEmail');
  const password = localStorage.getItem('userPassword');
  if (!email || !password) throw new Error('Credenciais não encontradas.');
  const { data } = await axios.post('/api/trade/digital/buy', { ...payload, email, password });
  return data;
}

const checkOrderStatus = async (orderId, uniqueId) => {
  const email = localStorage.getItem('userEmail');
  const password = localStorage.getItem('userPassword');
  if (!email || !password) throw new Error('Credenciais não encontradas.');
  const { data } = await axios.get('/api/order', { params: { email, password, orderId: Number(orderId), uniqueId, collection: COLLECTION_NAME } });
  return data;
}

const getAccountBalance = async () => {
  const email = localStorage.getItem('userEmail');
  const password = localStorage.getItem('userPassword');
  if (!email || !password) throw new Error('Credenciais não encontradas.');
  const { data } = await axios.post('/api/account/balance', { email, password });
  return data;
}

const getHistory = async () => {
  const email = localStorage.getItem('userEmail');
  if (!email) throw new Error('Email não encontrado.');
  const { data } = await axios.get('/api/order/history', { params: { email, collection: COLLECTION_NAME } });
  return data;
}

const getCandles = async (pair, period) => {
  const email = localStorage.getItem('userEmail');
  const password = localStorage.getItem('userPassword');
  if (!email || !password) throw new Error('Credenciais não encontradas.');
  const { data } = await axios.get('/api/candles', { params: { pair, period, email, password } });
  return data;
}

const getAvailableAssets = async () => {
  const email = localStorage.getItem('userEmail');
  const password = localStorage.getItem('userPassword');
  if (!email || !password) throw new Error('Credenciais não encontradas.');
  const { data } = await axios.get('/api/candles/digital', { params: { email, password } });
  return data;
}

// Função para obter o access_token via login na API
const getAccessToken = async () => {
  const url = 'https://api-signals.tradeautopilot.ai/auth/login';
  const payload = {
    email: 'windson3433@gmail.com',
    password: 'Dnscotty@123'
  };
  const { data } = await axios.post(url, payload, {
    headers: { 'Content-Type': 'application/json' }
  });
  return data.access_token;
};

const generateSignal = async (pair, timeframe, candles) => {
  const token = await getAccessToken();
  const url = 'https://api-signals.tradeautopilot.ai/signals';
  const { data } = await axios.post(
    url,
    { pair, timeframe: `M${timeframe}`, candles },
    { headers: { 'Authorization': `Bearer ${token}` } }
  );
  return data;
};

const getCurrencyFlag = (currencyPair, index) => {
    if (!currencyPair) return 'https://flagcdn.com/w20/un.png';
    const cleanPair = currencyPair.split('-')[0];
    const firstCurrency = cleanPair.substring(0, 3).toLowerCase();
    const secondCurrency = cleanPair.substring(3, 6).toLowerCase();
    const currencyToCountry = { 'eur': 'eu', 'usd': 'us', 'gbp': 'gb', 'jpy': 'jp', 'aud': 'au', 'cad': 'ca', 'chf': 'ch', 'nzd': 'nz', 'brl': 'br' };
    const currency = index === 0 ? firstCurrency : secondCurrency;
    const countryCode = currencyToCountry[currency] || currency;
    return `https://flagcdn.com/w20/${countryCode}.png`;
}

const updateBalance = async () => {
  try {
    const data = await getAccountBalance();
    const account = data.balances.find(b => b.type === accountType.value);
    balance.value = account ? account.amount : 0;
  } catch (e) { balance.value = 0; }
};

const updateAccountGrowthData = async () => {
  try {
    const data = await getHistory();
    history.value = Array.isArray(data) ? data : [];
  } catch (err) {
    console.error('Erro ao buscar histórico:', err);
    history.value = [];
  }
};

function loadUserSettings() {
  const saved = localStorage.getItem('botSettings');
  if (saved) userSettings.value = JSON.parse(saved);
}

onMounted(async () => {
  const storedName = localStorage.getItem('userName')
  if (storedName) userDisplayName.value = storedName
  
  loadUserSettings()
  await startSdk()
  await updateBalance()
  await updateAccountGrowthData()

  try {
    const assets = await getAvailableAssets();
    if(Array.isArray(assets) && assets.length > 0) {
        availableAssets.value = assets;
        selectedAsset.value = assets[0].name;
    }
  } catch (e) { console.error("Não foi possível carregar os ativos", e) }

  await updateChart()
  chartUpdateInterval = setInterval(updateChart, 15000)
});

watch([selectedAsset, selectedTime], async () => {
  if (chartUpdateInterval) clearInterval(chartUpdateInterval)
  chartSeries.value = [{ data: [] }] 
  await updateChart()
  chartUpdateInterval = setInterval(updateChart, 15000)
});

onUnmounted(() => {
  if (chartUpdateInterval) {
    clearInterval(chartUpdateInterval)
  }
});

</script>

<style scoped>
/* Glass Card Effect */
.glass-card {
  background: linear-gradient(135deg, rgba(15, 23, 42, 0.8), rgba(30, 41, 59, 0.4));
  border: 1px solid rgba(59, 130, 246, 0.2);
  backdrop-filter: blur(10px);
  box-shadow: 0 8px 32px rgba(0, 0, 0, 0.2);
}

.tab-button {
  padding: 0.375rem 0.75rem;
  border-radius: 0.5rem;
  font-size: 0.875rem;
  transition: all 0.2s;
}
.tab-button:hover {
  background-color: rgba(55, 65, 81, 0.5);
}
.tab-button.active {
  background-color: rgba(59, 130, 246, 0.2);
  color: #3B82F6;
}
.btn-green,
.text-green-500,
.text-green-400,
.bg-green-500,
.bg-green-400,
.border-green-500,
.border-green-400,
.from-green-500,
.to-green-500 {
  color: #3B82F6 !important;
  background-color: #1e293b !important;
  border-color: #3B82F6 !important;
}
.btn-green:hover,
.bg-green-500:hover {
  background-color: #6366F1 !important;
  color: #fff !important;
}
.text-success,
.badge-success {
  color: #3B82F6 !important;
  background: #1e293b !important;
  border-color: #3B82F6 !important;
}
.badge-active,
.status-active {
  background: #3B82F6 !important;
  color: #fff !important;
}
.badge-inactive,
.status-inactive {
  background: #6366F1 !important;
  color: #fff !important;
}
</style>